package practiceproject3part;
import java.io.*;
	public class LinkedList {
	    Node head;
    // Linked list Node
	    class Node {
	        int data;
	        Node next;
	        Node(int d)
	        {
	            data = d;
	            next = null;
	        }
	    }

    // Given a key, deletes the first occurrence of key in linked list
	    void deleteNode(int key)
	    {
	// Store head node
	        Node temp = head, prev = null;
	// If head node itself holds the key to be deleted
	        if (temp != null && temp.data == key) {

	// Changed head
	            head = temp.next;
	            return;
	        }

	        // Search for the key to be deleted, keep track of
	        // the previous node as we need to change temp.next
	        while (temp != null && temp.data != key) {
	            prev = temp;
	            temp = temp.next;
	        }

	        // If key was not present in linked list
	        if (temp == null)
	            return;

	        // Unlink the node from linked list
	        prev.next = temp.next;
	    }

	    // Inserts a new Node at front of the list.
	    public void push(int new_data)
	    {
	        Node new_node = new Node(new_data);
	        new_node.next = head;
	        head = new_node;
	    }

	    // This function prints contents of linked list
	    // starting from the given node
	    public void printList()
	    {
	        Node tnode = head;
	        while (tnode != null) {
	            System.out.print(tnode.data + " ");
	            tnode = tnode.next;
	        }
	    }

	 // method to create a Singly linked list with n nodes 
	    public static void main(String[] args)
	    {
	        LinkedList list = new LinkedList();

	        list.push(7);
	        list.push(1);
	        list.push(3);
	        list.push(2);
	        list.push(9);
	        list.push(5);
	        list.push(8);
	        

	        System.out.println("Created Linked List:");
	        list.printList();

	        // Delete node with data 1

	        list.deleteNode(1);
	        System.out.println( "\nLinked List after Deletion of 1:");
	        list.printList();
	        list.deleteNode(9);
	        System.out.println( "\nLinked List after Deletion of 9:");
	        list.printList();
	        list.deleteNode(3);
	        System.out.println( "\nLinked List after Deletion of 3:");
	        list.printList();
	    }
	}


