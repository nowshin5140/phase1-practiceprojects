package practiceproject3part;

public class helloworld {

	public static void main(String[] args) {
		System.out.println("Hello World");
		// TODO Auto-generated method stub

	}

}
