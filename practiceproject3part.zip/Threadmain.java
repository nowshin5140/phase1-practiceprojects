package practiceproject3part;
class NumberIteration extends Thread{
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println(i);
		}
	}
}
public class Threadmain {
	public static void main(String[] args) {
		NumberIteration itr1 = new NumberIteration();
		itr1.start();
		NumberIteration itr2 = new NumberIteration();
		itr2.start();
	}
	

}









