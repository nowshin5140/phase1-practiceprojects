package practiceproject3part;


	class RotateArray { 
		public void rotate(int[] array, int arr) {
		    		if(arr > array.length) 
		       			arr=arr%array.length;
		 		int[] result = new int[array.length];
		 		for(int i=0; i < arr; i++){
		        			result[i] = array[array.length-arr+i];
		 		}
		 		int j=0;
		    		for(int i=arr; i<array.length; i++){
		        			result[i] = array[j];
		j++;
		    		}
		 		System.arraycopy( result, 0, array, 0, array.length );
		}
		} 
		public class Main
		{
			public static void main(String[] args) {
				RotateArray r = new RotateArray();
		        		int arr1[] = { 7,9,3,6,0,5,1,11,19 }; 
		        		r.rotate(arr1,5); 
		        		for(int i=0;i<arr1.length;i++){
		            			System.out.print(arr1[i]+" ");
		        		}
			}
		}



